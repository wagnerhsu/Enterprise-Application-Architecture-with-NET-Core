﻿export class ServiceRequest {
    id: number;
    tenantID: number;
    description: string;
    employeeComments: string;
    statusId: number;
}