﻿import { Component } from '@angular/core';

@Component({
    selector: 'tenant-mgmt',
    templateUrl: 'Feature/Index'
})
export class AppComponent {
}