﻿import { Component, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
    selector: 'menu',
    templateUrl: 'Feature/Menu'
})
export class MenuComponent {

}