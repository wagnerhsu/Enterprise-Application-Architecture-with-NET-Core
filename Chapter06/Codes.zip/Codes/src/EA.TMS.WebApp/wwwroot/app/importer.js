﻿        System.import('app/main').catch(function (err) {
            console.error(err);
        });
