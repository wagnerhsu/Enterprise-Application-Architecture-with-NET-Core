"use strict";
var ServiceRequest = (function () {
    function ServiceRequest() {
    }
    return ServiceRequest;
}());
exports.ServiceRequest = ServiceRequest;
//# sourceMappingURL=data-models.interface.js.map