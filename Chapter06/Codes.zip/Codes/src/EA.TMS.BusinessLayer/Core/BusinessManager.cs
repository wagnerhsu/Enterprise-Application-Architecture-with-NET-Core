﻿using EA.TMS.DataAccess.Core;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EA.TMS.Common.Facade;
using EA.TMS.Common.Entities;

namespace EA.TMS.BusinessLayer.Core
{
    public abstract class BusinessManager
    {
    }
}
